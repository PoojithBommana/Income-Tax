Total_income_Earn_by_you = float(input())
Discount_on_Total_Income = Total_income_Earn_by_you - 50000

if Total_income_Earn_by_you <= 250000:  #2 Lakh 50 thousand
    tax = 0
# Above Line We are telling that If our income Is less than 2 lakh 50 k the tax should be 0
elif Total_income_Earn_by_you <= 500000: 
    tax = (Discount_on_Total_Income - 250000) * 0.05
# Above Line We are telling that If our income Is Lesser than 5 Lakh and Greater than 2 Lakh the tax should be 5%

elif Total_income_Earn_by_you <= 750000: #7 lakh 50 thousand
    tax = (Discount_on_Total_Income - 500000) * 0.10 + 12500 
# Above Line We are telling that If our income Is  Lesser than 7Lakh 50K  and Greater than 5 Lakh the tax should be 10% 

elif Total_income_Earn_by_you <= 1000000: #10 Lakh
    tax = (Discount_on_Total_Income - 750000) * 0.15 + 37500 
# Above Line We are telling that If our income Is  Lesser than 10 Lakh and Greater than  7Lakh 50K the tax should be 15%

elif Total_income_Earn_by_you <= 1250000: #12 lakh 50 thousand
    tax = (Discount_on_Total_Income - 1000000) * 0.20 + 75000 
# Above Line We are telling that If our income Is  Lesser than 12 Lakh 50K and Greater than 10 Lakh the tax should be 20% 

elif Total_income_Earn_by_you <= 1500000: #15 lakh
    tax = (Discount_on_Total_Income - 1250000) * 0.25 + 125000 
# Above Line We are telling that If our income Is  GLesser than 15 Lakh and Greater than 12 Lakh 50K the tax should be 25%

else:
    tax = (Discount_on_Total_Income - 1500000) * 0.30 + 187500

print("Tax For your Income Will ", tax, " in Rupees!")